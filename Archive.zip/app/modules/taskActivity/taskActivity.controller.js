const catchAsync = require("../../../shared/catchAsync");
const db = require("../../../models");
const sendResponse = require("../../../shared/sendResponse");
const TaskActivityService = require("./taskActivity.service");

const getTaskActivity = catchAsync(async (req, res) => {
  const result = await TaskActivityService.getActivityByTask(req.params.taskId);

  sendResponse(res, {
    statusCode: 200,
    success: true,
    data: result,
  });
});

const getAllTaskActivity = catchAsync(async (req, res) => {
  const user = await db.user.findByPk(req.user?.id, {
    attributes: ["id", "Role", "Branch"],
  });

  if (!["admin", "superAdmin"].includes(user?.Role)) {
    return res.status(403).json({
      status: "fail",
      error: "Forbidden",
    });
  }

  const branch = user.Role === "admin" ? user.Branch : req.query.branch;
  const result = await TaskActivityService.getAllActivity({ branch });

  sendResponse(res, {
    statusCode: 200,
    success: true,
    data: result,
  });
});

module.exports = {
  getTaskActivity,
  getAllTaskActivity,
};
